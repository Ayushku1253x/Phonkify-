# Phonkify API backend

The API is a lightweight audio remix MVP. It decodes uploaded audio with FFmpeg, adds synthesized kick/snare/cowbell patterns and saturation, exports WAV versions, and optionally sends the source audio to AudD for recognition.

## Run locally
```bash
cd backend
pip install -r requirements.txt
uvicorn phonkify.api:app --host 0.0.0.0 --port 8000
```
FFmpeg must be installed. Health check: `http://localhost:8000/health`.

## Deploy
Build the included Dockerfile on a container host that supports persistent web services. Set the public HTTPS URL in the Android app's Backend connection field. GPU is not required for this basic DSP engine. This MVP does **not** use Demucs or a generative music model; vocal separation and true AI-generated arrangements are not implemented.

## AudD
Obtain an API key from AudD and enter it in the app. Recognition availability, file-size limits, pricing and terms are controlled by AudD. A match is only a possible identification; no match is not legal clearance. The backend never automatically removes copyrighted portions because that could create silent gaps and does not grant rights.
