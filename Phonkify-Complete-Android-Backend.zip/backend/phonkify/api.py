import io, os, zipfile, tempfile, subprocess, shutil
from pathlib import Path
from typing import List
import numpy as np
import soundfile as sf
import requests
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import StreamingResponse
from scipy.signal import butter, sosfilt

app = FastAPI(title="Phonkify API", version="1.0.0")
STYLES = {
    "drift": {"bpm": 140, "cowbell": 0.22, "bass": 0.42, "drive": 1.5},
    "memphis": {"bpm": 130, "cowbell": 0.12, "bass": 0.52, "drive": 2.0},
    "aggressive": {"bpm": 150, "cowbell": 0.18, "bass": 0.62, "drive": 3.0},
    "slowed": {"bpm": 118, "cowbell": 0.08, "bass": 0.35, "drive": 1.2},
    "cowbell": {"bpm": 135, "cowbell": 0.45, "bass": 0.40, "drive": 1.7},
}
LABELS = {"drift":"Drift Classic","memphis":"Dark Memphis","aggressive":"Hard Aggressive","slowed":"Slowed + Reverb","cowbell":"Cowbell Funk"}

@app.get("/health")
def health():
    return {"status":"ok","service":"Phonkify API","styles":list(STYLES)}

@app.get("/styles")
def styles():
    return [{"id":k,"name":LABELS[k],"bpm":v["bpm"]} for k,v in STYLES.items()]

def decode_audio(path: str):
    # FFmpeg normalizes common mobile formats to 44.1kHz stereo WAV.
    out = path + ".wav"
    p = subprocess.run(["ffmpeg","-y","-i",path,"-vn","-ac","2","-ar","44100",out],
                       capture_output=True, text=True)
    if p.returncode != 0:
        raise ValueError("Unsupported or unreadable audio file: " + p.stderr[-300:])
    audio, sr = sf.read(out, dtype="float32", always_2d=True)
    os.remove(out)
    return audio, sr

def synth_kick(sr, duration=0.16):
    n=int(sr*duration); t=np.arange(n)/sr
    freq=48+90*np.exp(-t*24)
    phase=2*np.pi*np.cumsum(freq)/sr
    env=np.exp(-t*20)
    return (np.sin(phase)*env*0.85).astype(np.float32)

def synth_snare(sr, duration=0.13):
    n=int(sr*duration); t=np.arange(n)/sr
    rng=np.random.default_rng(42)
    noise=rng.normal(0,1,n).astype(np.float32)
    return noise*np.exp(-t*28)*0.24

def synth_cowbell(sr, duration=0.11):
    n=int(sr*duration); t=np.arange(n)/sr
    x=(np.sin(2*np.pi*560*t)+0.7*np.sin(2*np.pi*845*t))*np.exp(-t*18)
    return (x*0.18).astype(np.float32)

def add_hit(mix, hit, pos, gain=1.0):
    if pos >= len(mix): return
    end=min(len(mix),pos+len(hit))
    mix[pos:end] += hit[:end-pos]*gain

def phonk_mix(audio, sr, style):
    cfg=STYLES[style]
    if style == "slowed":
        # A subtle slower playback effect via resampling, with original duration preserved by interpolation.
        indices=np.arange(0,len(audio),1.0/0.88)
        indices=np.minimum(indices, len(audio)-1)
        audio=audio[indices.astype(int)]
    n=len(audio)
    mix=audio.copy()
    beat=60.0/cfg["bpm"]
    step=max(1,int(sr*beat/2))
    kick=synth_kick(sr); snare=synth_snare(sr); bell=synth_cowbell(sr)
    drum=np.zeros((n,2),dtype=np.float32)
    total_steps=int(np.ceil(n/step))
    for i in range(total_steps):
        pos=i*step
        bar=i%8
        if i%4 in (0,2): add_hit(drum,kick,pos,0.75 if bar else 0.9)
        if i%4==2: add_hit(drum,snare,pos,0.65)
        if i%2==1 and (style in ("drift","cowbell","aggressive")): add_hit(drum,bell,pos,0.7)
    # Stereo spread and gentle saturation; do not clip the output.
    mono=drum[:,0]
    drum[:,1]=mono*0.92
    mixed=mix*(0.88 if style!="aggressive" else 0.78) + drum*cfg["bass"]
    drive=cfg["drive"]
    mixed=np.tanh(mixed*drive)/np.tanh(drive)
    peak=float(np.max(np.abs(mixed))) if mixed.size else 1.0
    if peak>0.98: mixed*=0.98/peak
    return mixed.astype(np.float32)

def audd_scan(path: str, api_key: str):
    if not api_key: return {"status":"skipped","reason":"AudD API key not configured"}
    # AudD accepts a complete audio file. Provider limits/pricing apply.
    with open(path,"rb") as f:
        r=requests.post("https://api.audd.io/", data={"api_token":api_key,"return":"spotify"}, files={"file":f}, timeout=90)
    if r.status_code != 200: return {"status":"error","reason":f"AudD HTTP {r.status_code}"}
    data=r.json()
    if data.get("status") != "success": return {"status":"error","reason":data.get("error","Recognition failed")}
    result=data.get("result")
    if not result: return {"status":"no_match","note":"No match returned; this is not copyright clearance."}
    return {"status":"match","title":result.get("title"),"artist":result.get("artist"),"album":result.get("album")}

@app.post("/process")
async def process(files: List[UploadFile] = File(...), style: str = Form("all"),
                  copyright_check: bool = Form(True), audd_api_key: str = Form("")):
    if not files: raise HTTPException(400,"Upload at least one audio file")
    chosen=list(STYLES) if style=="all" else [style]
    if any(s not in STYLES for s in chosen): raise HTTPException(400,"Unknown style")
    memory=io.BytesIO()
    report=[]
    with tempfile.TemporaryDirectory() as td, zipfile.ZipFile(memory,"w",zipfile.ZIP_DEFLATED) as z:
        for idx, up in enumerate(files):
            name=Path(up.filename or f"track_{idx+1}.audio").name
            raw=await up.read()
            if len(raw)>150*1024*1024: raise HTTPException(413,f"{name} exceeds 150 MB")
            src=os.path.join(td,f"{idx}_{name}")
            with open(src,"wb") as f: f.write(raw)
            try:
                audio,sr=decode_audio(src)
                scan=audd_scan(src,audd_api_key) if copyright_check else {"status":"disabled"}
                for s in chosen:
                    output=phonk_mix(audio,sr,s)
                    buf=io.BytesIO()
                    sf.write(buf,output,sr,format="WAV",subtype="PCM_16")
                    outname=f"{Path(name).stem}_{s}.wav"
                    z.writestr(outname,buf.getvalue())
                    report.append({"file":name,"style":LABELS[s],"bpm":STYLES[s]["bpm"],"copyright":scan})
            except Exception as e:
                report.append({"file":name,"error":str(e)})
        z.writestr("report.json",__import__("json").dumps(report,indent=2))
    memory.seek(0)
    return StreamingResponse(memory,media_type="application/zip",
        headers={"Content-Disposition":'attachment; filename="phonkify-results.zip"'})
