# Phonkify — Android + Audio API (single project)

This repository contains:
- Android app with minimal dark/purple UI
- Multi-audio picker
- Five remix presets and batch/all-styles selection
- Backend URL and optional AudD API key settings
- ZIP export flow from the API
- FastAPI audio-processing backend with FFmpeg decoding and generated drum/cowbell remix layers
- Optional AudD recognition
- GitHub Actions workflow to build a debug APK

## Important honest feature status
The included backend implements a **rule-based DSP phonk-style remix MVP**, not a generative AI model. It does not currently perform AI vocal separation, automatic best-version ranking, timestamped fingerprint matching, or automatic copyright removal. AudD recognition is optional and requires your own API key. A no-match result is not copyright permission. Use only tracks you own or are licensed to remix.

## Build APK
1. Create a GitHub repository and upload all files in this ZIP to its root (include hidden `.github` folder).
2. Open Actions → **Build Phonkify APK** → Run workflow.
3. Download the `Phonkify-debug-apk` artifact from the successful workflow run.
4. Extract that artifact ZIP and install `app-debug.apk` on Android.

## Connect audio processing
1. Deploy `backend/` using its Dockerfile to a public container host with HTTPS.
2. Open Phonkify → Backend connection → replace the placeholder URL with your HTTPS backend URL.
3. Optional: enter an AudD API key under Copyright scan.
4. Choose songs and a style, then tap Create my phonk.

The ZIP contains both Android and backend source. Hosting the backend and obtaining any third-party API key require separate accounts/actions; GitHub Actions only builds the APK.
