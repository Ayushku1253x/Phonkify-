package com.phonkify.app

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF08070D)
private val Surface = Color(0xFF15131E)
private val Surface2 = Color(0xFF211A30)
private val Violet = Color(0xFF9B4DFF)
private val MainText = Color(0xFFF7F4FF)
private val Muted = Color(0xFFA49BB8)
private val http = OkHttpClient.Builder().callTimeout(20, TimeUnit.MINUTES).build()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhonkifyScreen() }
    }
}

@Composable
private fun PhonkifyScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(listOf<Uri>()) }
    var style by remember { mutableStateOf("drift") }
    var apiUrl by remember { mutableStateOf(BuildConfig.DEFAULT_API_URL) }
    var auddKey by remember { mutableStateOf("") }
    var copyright by remember { mutableStateOf(true) }
    var makeAll by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Connect your backend URL to start processing.") }
    var resultBytes by remember { mutableStateOf<ByteArray?>(null) }
    var resultName by remember { mutableStateOf("phonkify-results.zip") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) {
        if (it.isNotEmpty()) files = (files + it).distinct()
    }
    val saveZip = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null && resultBytes != null) {
            runCatching { context.contentResolver.openOutputStream(uri)?.use { out -> out.write(resultBytes!!) } }
                .onSuccess { status = "Saved $resultName to your phone." }
                .onFailure { status = "Save failed: ${it.message}" }
        }
    }

    suspend fun process() {
        if (files.isEmpty()) { status = "Add at least one audio file first."; return }
        if (!apiUrl.startsWith("https://")) { status = "Enter a valid HTTPS backend URL in Settings."; return }
        busy = true
        status = "Uploading songs and processing… keep the app open."
        resultBytes = null
        try {
            val parts = withContext(Dispatchers.IO) {
                val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("style", if (makeAll) "all" else style)
                    .addFormDataPart("copyright_check", copyright.toString())
                    .addFormDataPart("audd_api_key", auddKey)
                files.forEachIndexed { i, uri ->
                    val temp = File(context.cacheDir, "upload_${i}_${System.currentTimeMillis()}.audio")
                    context.contentResolver.openInputStream(uri)!!.use { input -> temp.outputStream().use(input::copyTo) }
                    builder.addFormDataPart("files", temp.name, temp.asRequestBody("application/octet-stream".toMediaType()))
                }
                builder.build()
            }
            val base = apiUrl.trimEnd('/')
            val req = Request.Builder().url("$base/process").post(parts).build()
            val response = withContext(Dispatchers.IO) { http.newCall(req).execute() }
            response.use {
                if (!it.isSuccessful) error("Server returned HTTP ${it.code}: ${it.body?.string()?.take(500)}")
                resultBytes = it.body?.bytes() ?: error("Empty response")
            }
            status = "Finished. Your result ZIP is ready to save."
            saveZip.launch("Phonkify-Results.zip")
        } catch (e: Exception) {
            status = "Could not process: ${e.message}. Check backend URL and internet."
        } finally { busy = false }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Surface, primary = Violet, onBackground = MainText, onSurface = MainText)) {
        Column(Modifier.fillMaxSize().background(Ink).statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("∿", color = Violet, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text("Phonkify", color = MainText, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("YOUR PERSONAL PHONK STUDIO", color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
                }
                Text("SETUP", color = Violet, fontSize = 10.sp, modifier = Modifier.clickable { status = "Edit the backend URL below. AudD key is optional." })
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(16.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                item {
                    Column {
                        Text("Make it", color = MainText, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("hit different.", color = Violet, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text("Turn your permitted tracks into phonk.", color = Muted, fontSize = 12.sp)
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(20.dp)).padding(16.dp)) {
                        Text("YOUR TRACKS", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("${files.size} songs selected", color = MainText, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Text("+  Add multiple songs", color = Violet)
                        }
                        files.take(4).forEach { Text("♫  ${it.lastPathSegment ?: "Audio file"}", color = Muted, fontSize = 11.sp, maxLines = 1) }
                        if (files.size > 4) Text("+ ${files.size - 4} more", color = Violet, fontSize = 11.sp)
                    }
                }
                item {
                    Column {
                        Text("Choose your sound", color = MainText, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(9.dp))
                        val styles = listOf("drift" to "Drift Classic", "memphis" to "Dark Memphis", "aggressive" to "Hard Aggressive", "slowed" to "Slowed + Reverb", "cowbell" to "Cowbell Funk")
                        styles.chunked(2).forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { (id, label) ->
                                    val active = style == id
                                    Box(Modifier.weight(1f).padding(bottom = 8.dp).background(if (active) Violet.copy(alpha = .2f) else Surface, RoundedCornerShape(12.dp)).clickable { style = id }.padding(13.dp)) {
                                        Text((if (active) "●  " else "○  ") + label, color = if (active) MainText else Muted, fontSize = 11.sp)
                                    }
                                }
                                if (row.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = makeAll, onCheckedChange = { makeAll = it }, colors = CheckboxDefaults.colors(checkedColor = Violet))
                            Text("Generate all 5 styles", color = MainText, fontSize = 12.sp)
                        }
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(16.dp)).padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Copyright scan", color = MainText, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Switch(checked = copyright, onCheckedChange = { copyright = it })
                        }
                        Text("Uses AudD if an API key is provided. No match is not legal clearance.", color = Muted, fontSize = 11.sp)
                        OutlinedTextField(value = auddKey, onValueChange = { auddKey = it }, label = { Text("AudD API key (optional)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Surface, RoundedCornerShape(16.dp)).padding(14.dp)) {
                        Text("Backend connection", color = MainText, fontWeight = FontWeight.Bold)
                        OutlinedTextField(value = apiUrl, onValueChange = { apiUrl = it }, label = { Text("HTTPS backend URL") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        Text("Backend must be deployed and reachable. The included backend source is in this project.", color = Muted, fontSize = 10.sp)
                    }
                }
                item {
                    Button(onClick = { scope.launch { process() } }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(15.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
                        if (busy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Text("CREATE MY PHONK  →", fontWeight = FontWeight.Bold)
                    }
                }
                item { Text(status, color = Muted, fontSize = 11.sp, lineHeight = 16.sp) }
            }
            Text("HOME     •     REMIX     •     EXPORT", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 12.dp))
        }
    }
}
